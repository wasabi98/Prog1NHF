#include "megjelenites.h"
#include <stdlib.h>
void rajzol(SDL_Renderer *renderer, SDL_Texture *sprite,Mezo melyik, int x, int y)
{
    SDL_Rect src = {(melyik%5)*16 ,(melyik/5)*16, 16,16};
    SDL_Rect dest = {x,y,16,16};
    SDL_RenderCopy(renderer, sprite, &src, &dest);
}
void ablak(SDL_Renderer **prenderer, SDL_Window **pwindow, int szeles, int magas, char *cim)
{


    SDL_Window *window = SDL_CreateWindow(  cim,
                                SDL_WINDOWPOS_CENTERED,
                                SDL_WINDOWPOS_CENTERED,
                                szeles,
                                magas,
                                0);
    if(window == NULL)
    {
        printf("SDL inicializalasi hiba: %s", SDL_GetError());      //DOLGOZZ!!!!!!!!!

    }

    SDL_Renderer *renderer = SDL_CreateRenderer(window,
                                  -1,
                                  SDL_RENDERER_SOFTWARE);
    SDL_RenderClear(renderer);

    if(renderer == NULL)
    {
        printf("SDL render hiba: %s", SDL_GetError());

    }


    *pwindow = window;
    *prenderer = renderer;


}

int Menu(SDL_Event *event, SDL_Renderer *renderer, SDL_Window *window)
{
    SDL_Init(SDL_INIT_VIDEO);

    ablak(&renderer, &window, 200, 500, "Aknakereso");

    SDL_Texture *menu = IMG_LoadTexture(renderer, "menu.png");
    if(menu == NULL)
    {
        printf("A menu-t nem lehet megnyitni: %s", IMG_GetError());
        return 1;
    }



    SDL_RenderClear(renderer);
    SDL_RenderCopy(renderer, menu, NULL, NULL);
    SDL_RenderPresent(renderer);


    while(1)
    {
        SDL_WaitEvent(event);
        switch(event->type)
        {
        case SDL_MOUSEBUTTONDOWN:
            if(event->button.button == SDL_BUTTON_LEFT)
            {
                switch(event->motion.y/100)
                {
                    case 0:
                        SDL_DestroyTexture(menu);
                        return 0;
                        break;
                    case 1:
                        SDL_DestroyTexture(menu);
                        return 1;
                        break;
                    case 2:
                        SDL_DestroyTexture(menu);
                        return 2;
                        break;
                    case 3:
                        SDL_DestroyTexture(menu);
                        return 3;
                        break;
                    case 4:
                    case 5:
                        SDL_DestroyTexture(menu);
                        return 4;
                        break;
                }
            }
        case SDL_QUIT:
            SDL_DestroyTexture(menu);
            return -1;
            break;
        }
    }


}

