#ifndef JATEK_H_INCLUDED
#define JATEK_H_INCLUDED

#include <SDL2/SDL.h>

void Jatek(SDL_Renderer* renderer, SDL_Window* window, SDL_Event* event, int szeles, int magas, int akna);

#endif // JATEK_H_INCLUDED
