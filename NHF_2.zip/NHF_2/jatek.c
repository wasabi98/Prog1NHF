#include "jatek.h"
#include "megjelenites.h"
#include "palya.h"

#include <stdbool.h>

void Jatek(SDL_Renderer *renderer,SDL_Window* window, SDL_Event * event, int szeles,int magas, int akna)
{
    SDL_RenderClear(renderer);
    bool gameover = false;
    SDL_SetWindowSize(window, szeles*16,magas*16);


    int x;
    int y;

    Negyzet **palya;

    palya = (Negyzet**) malloc(magas * sizeof(Negyzet*));
    for (int y = 0; y < magas; ++y)
    palya[y] = (Negyzet*) malloc(szeles * sizeof(Negyzet));


    palya_ures(palya,magas,szeles);
    feltolt(palya,magas,szeles,akna);
    szamoz(palya, magas,szeles);

    SDL_Texture *sprite = IMG_LoadTexture(renderer, "sprite.png");
        if(sprite == NULL)
        {
            printf("A sprite-ot nem lehet megnyitni: %s", IMG_GetError());
        }
    for(int i = 0; i < magas;i++)
        {
            for(int j = 0; j < szeles;j++)
            {
                rajzol(renderer, sprite, Fedett, i*16,j*16);
            }
        }



    while(!gameover)
    {

        x = (event->motion.x-(event->motion.x%16))/16;
        y = (event->motion.y-(event->motion.y%16))/16;


        switch(event->type)
            {

            case SDL_MOUSEBUTTONDOWN:

                if(event->button.button == SDL_BUTTON_LEFT && palya[x][y].zaszlo != true)
                {


                    switch(palya[x][y].szam)
                    {
                        case 0:
                            rajzol(renderer, sprite, Ures, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 1:
                            rajzol(renderer, sprite, Egy, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 2:
                            rajzol(renderer, sprite, Ketto, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 3:
                            rajzol(renderer, sprite, Harom, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 4:
                            rajzol(renderer, sprite, Negy, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 5:
                            rajzol(renderer, sprite, Ot, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 6:
                            rajzol(renderer, sprite, Hat, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 7:
                            rajzol(renderer, sprite, Het, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 8:
                            rajzol(renderer, sprite, Nyolc, x*16, y*16);
                            palya[x][y].felfedve=true;
                            break;
                        case 9:
                            rajzol(renderer, sprite, Akna, x*16, y*16);
                            palya[x][y].felfedve=true;
                            gameover = true;
                            break;



                    }

                }
                else if(event->button.button == SDL_BUTTON_RIGHT)
                {
                    if(palya[x][y].felfedve == false)
                    {
                        if(palya[x][y].zaszlo == true)
                        {
                            rajzol(renderer, sprite, Fedett, x*16, y*16);
                            palya[x][y].zaszlo = false;
                        }
                        else
                        {
                            rajzol(renderer, sprite, Zaszlo, x*16, y*16);
                            palya[x][y].zaszlo = true;
                        }
                    }
                }
                break;
            }
            if(event->type == SDL_QUIT)
            {
                gameover = true;
            }
            SDL_RenderPresent(renderer);
    }
    //fajlbairaas
    for (int y = 0; y < magas; ++y)
    free(palya[y]);
    free(palya);

}
