#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#include "megjelenites.h"
#include "palya.h"
#include "jatek.h"


int main(int argc, char *argv[]) {

    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;

    srand(time(NULL));
    SDL_Event event;
    bool menufut = true;
    bool gameover = false;


    int menu_valasztas = Menu(&event, renderer, window);
    switch(menu_valasztas)
    {
        case -1:
            break;
        case 0:

            Jatek(renderer, window, &event, 9, 9, 10); //rohad�s
            break;
        case 1:
            Jatek(renderer, window, &event, 16, 16, 40); //f�lelem
            break;
        case 2:
            Jatek(renderer, window, &event, 16, 30, 99);//szenved�s
            break;
        case 3:
            break;
        case 4:
            break;

    }





    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();
    return 0;
}
