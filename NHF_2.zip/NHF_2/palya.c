#include "palya.h"

void palya_ures(Negyzet **palya, int szeles, int magas)
{
    for(int i = 0; i < szeles;i++)
    {
        for(int j = 0; j < magas; j++)
        {
            palya[i][j].szam = 0;
            palya[i][j].felfedve = false;
            palya[i][j].zaszlo = false;
        }
    }

}
void feltolt(Negyzet **palya, int szeles, int magas, int akna)
{
    int szamlalo = 0;
    while(szamlalo != akna)
    {
        int x = rand()%szeles;
        int y = rand()%magas;

    if(palya[x][y].szam== 9)
    {
        continue;
    }
    else
    {
        palya[x][y].szam=9;
        szamlalo++;
    }
    }

}

void szamoz(Negyzet **palya, int szeles, int magas)
{
    for(int i = 0; i < szeles;i++)
    {
        for(int j = 0;j < magas; j++)
        {
            if(palya[i][j].szam !=9)
            {
                for(int k = i-1;k <= i+1;k++)
                {
                    for(int l = j-1; l<= j+1;l++)
                    {
                        if(!(k == i && l == j))
                        {
                            if(!(k<0 || l<0 || k>(szeles-1) || l>(magas-1)))
                            {
                              if(palya[k][l].szam == 9)
                              {
                                  palya[i][j].szam++;
                              }
                            }
                        }
                    }
                }
            }
        }
    }
}
