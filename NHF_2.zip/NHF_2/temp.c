#include <SDL2/SDL.h>
#include <SDL2/SDL2_gfxPrimitives.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

#include "megjelenites.h"
#include "palya.h"


int main(int argc, char *argv[]) {

    SDL_Window *window = NULL;
    SDL_Renderer *renderer = NULL;

    SDL_Init(SDL_INIT_VIDEO);

    ablak(&renderer, &window, 200, 500, "Menu");

    SDL_Texture *menu = IMG_LoadTexture(renderer, "menu.png");
    if(menu == NULL)
    {
        printf("A kepet nem lehet megnyitni: %s", IMG_GetError());
        return 1;
    }


    srand(time(NULL));
    SDL_Event event;
    bool menufut = true;

    int x;
    int y;

    SDL_RenderCopy(renderer, menu, NULL, NULL);
    while(menufut)
    {
        SDL_WaitEvent(&event);


        switch(event.type)
        {

        case SDL_MOUSEBUTTONDOWN:
            if(event.button.button == SDL_BUTTON_LEFT)
            {
                switch(event.motion.y/100)
                {

                case 0:
                    SDL_SetWindowSize(window, 9*16,9*16);
                    SDL_RenderClear(renderer);
                    Negyzet **palya;

                    palya = (Negyzet**) malloc(9 * sizeof(Negyzet*));
                    for (int y = 0; y < 9; ++y)
                    palya[y] = (Negyzet*) malloc(9 * sizeof(Negyzet));

                    SDL_Texture *sprite = IMG_LoadTexture(renderer, "sprite.png");
                        if(sprite == NULL)
                        {
                            printf("A kepet nem lehet megnyitni: %s", IMG_GetError());
                        }
                    for(int i = 0; i < 9;i++)
                        {
                            for(int j = 0; j < 9;j++)
                            {
                                rajzol(renderer, sprite, Fedett, i*16,j*16);
                            }
                        }

                    while(!gameover)
                    {
                        SDL_WaitEvent(&event);
                        x = (event.motion.x-(event.motion.x%16))/16;
                        y = (event.motion.y-(event.motion.y%16))/16;





                        palya_ures(palya,9,9);
                        feltolt(palya,9,9,10);
                        szamoz(palya, 9,9);



                        switch(event.type)
                        {

                        case SDL_MOUSEBUTTONDOWN:

                            if(event.button.button == SDL_BUTTON_LEFT && palya[x][y].zaszlo != true)
                            {


                                switch(palya[x][y].szam)
                                {
                                    case 0:
                                        rajzol(renderer, sprite, Ures, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 1:
                                        rajzol(renderer, sprite, Egy, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 2:
                                        rajzol(renderer, sprite, Ketto, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 3:
                                        rajzol(renderer, sprite, Harom, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 4:
                                        rajzol(renderer, sprite, Negy, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 5:
                                        rajzol(renderer, sprite, Ot, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 6:
                                        rajzol(renderer, sprite, Hat, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 7:
                                        rajzol(renderer, sprite, Het, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 8:
                                        rajzol(renderer, sprite, Nyolc, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        break;
                                    case 9:
                                        rajzol(renderer, sprite, Akna, x*16, y*16);
                                        palya[x][y].felfedve=true;
                                        gameover = true;
                                        break;



                                }

                            }
                            else if(event.button.button == SDL_BUTTON_RIGHT)
                            {
                                if(palya[x][y].felfedve == false)
                                {
                                    if(palya[x][y].zaszlo == true)
                                    {
                                        rajzol(renderer, sprite, Fedett, x*16, y*16);
                                        palya[x][y].zaszlo = false;
                                    }
                                    else
                                    {
                                        rajzol(renderer, sprite, Zaszlo, x*16, y*16);
                                        palya[x][y].zaszlo = true;
                                    }
                                }
                            }

                        }
                        if(event.type == SDL_QUIT)
                        {
                            gameover = true;
                        }
                        SDL_RenderPresent(renderer);
                    }
                    for(int i = 0; i < 9;i++)
                    {
                        for(int j = 0; j < 9; j++)
                        {
                            printf("%d ", palya[i][j].szam);
                        }
                        printf("\n");
                    }

                    break;
                case 1:
                    printf("kozep");
                    break;
                case 2:
                    printf("nehez");
                    break;
                case 3:
                    printf("sajat");
                    break;
                case 4:
                case 5:
                    printf("tolt");
                    break;
                }
            }
        break;
        case SDL_QUIT:
            menufut = false;
            break;
        }
     SDL_RenderPresent(renderer);
    }




    SDL_DestroyTexture(menu);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);

    SDL_Quit();
    return 0;
}
