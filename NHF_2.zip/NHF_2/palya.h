#ifndef PALYA_H_INCLUDED
#define PALYA_H_INCLUDED

#include <stdbool.h>
typedef struct Negyzet
    {
        bool felfedve;
        bool zaszlo;
        int szam;
    }Negyzet;

void palya_ures(Negyzet **palya, int szeles, int magas);
void feltolt(Negyzet **palya, int szeles, int magas, int akna);
void szamoz(Negyzet **palya, int szeles, int magas);
#endif // PALYA_H_INCLUDED
