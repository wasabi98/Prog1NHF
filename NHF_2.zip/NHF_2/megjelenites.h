#ifndef MEGJELENITES_H_INCLUDED
#define MEGJELENITES_H_INCLUDED

#include <stdio.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

typedef enum Mezo
{
    Fedett, Zaszlo, Akna, Ures, Robbano,
    Egy, Ketto, Harom, Negy, Teves,
    Ot, Hat, Het, Nyolc
}Mezo;

void ablak(SDL_Renderer **prenderer, SDL_Window **pwindow, int szeles, int magas, char *cim);
void rajzol(SDL_Renderer *renderer, SDL_Texture *sprite,Mezo melyik, int x, int y);
int Menu(SDL_Event *event, SDL_Renderer *renderer, SDL_Window *window);
#endif // MEGJELENITES_H_INCLUDED
